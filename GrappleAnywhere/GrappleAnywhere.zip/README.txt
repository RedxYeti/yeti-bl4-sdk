Install:
Merge sdk_mods and OakGame folders with the ones in your BL4 base directory

in-game set your grapple anywhere keys in the console

optionally disable the vanilla grapple points


Notes:
To use the Grapple to Ledge you need to aim directly at the top ledge of something you could mantle. 
If you aim correctly, you will land on top of the ledge you aimed at.